# Backend System

Use open-source foundations for proven infrastructure and domain-neutral behavior, then adapt through explicit application boundaries. Fit the backend to traffic, data, compliance, team, and deployment environment.

## Inspect First

Identify runtime, framework, package manager, API style, persistence, migrations, authentication, authorization, queues/jobs, caching, storage, observability, deployment target, tests, trust boundaries, and highest-risk operations.

## Candidate Foundations

Examples for discovery; select only those compatible with the repository and verify current maintenance and licensing.

- TypeScript/JavaScript: [Fastify](https://fastify.dev), [NestJS](https://nestjs.com), [Hono](https://hono.dev), framework-native server routes.
- Python: [FastAPI](https://fastapi.tiangolo.com), [Django](https://www.djangoproject.com), [Litestar](https://litestar.dev).
- Go: [Chi](https://go-chi.io), [Gin](https://gin-gonic.com), or the standard library.
- Data: [PostgreSQL](https://www.postgresql.org), [SQLite](https://www.sqlite.org), [Prisma](https://www.prisma.io), [Drizzle ORM](https://orm.drizzle.team), [SQLAlchemy](https://www.sqlalchemy.org).
- Authentication: [Keycloak](https://www.keycloak.org), [Authentik](https://goauthentik.io), [Ory](https://www.ory.sh), or a compatible library.
- API contracts: OpenAPI, JSON Schema, Protocol Buffers, GraphQL schemas, or shared runtime schemas.
- Testing: framework-native clients, [Vitest](https://vitest.dev), [pytest](https://pytest.org), integration tests, and real database tests where query behavior matters.

Do not introduce a service merely because a self-hosted edition exists. Include operations, upgrades, backup/restore, security response, and managed alternatives in the decision.

## Adaptation Boundaries

Prefer: transport -> application/use cases -> domain rules -> ports -> infrastructure adapters.

Keep request objects, ORM records, provider SDK types, and vendor exceptions at the edges. Wrap upstream code when local behavior differs. Fork only when wrapping cannot provide required behavior or a critical fix cannot land in time. Never silently patch installed packages or generated vendor directories.

## API And Data Rules

- Define request, response, error, and pagination contracts. Validate at the boundary and return stable machine-readable error codes.
- Enforce authorization on the server for every protected resource and action.
- Use database constraints for durable invariants and clear application errors.
- Make migrations forward-safe, review generated SQL, and define recovery for destructive changes.
- Use transactions around multi-write invariants. Make retried commands and webhook/job handlers idempotent.
- Avoid unbounded reads and fan-out; add pagination, indexes, query budgets, and timeouts.
- Separate secrets from configuration, validate required configuration at startup, and never commit credentials.
- Apply rate, size, upload, CSRF, SSRF, and redirect controls where the attack surface requires them.
- Log structured events with correlation identifiers while excluding secrets and unnecessary personal data.

## Authentication And Authorization

Prefer established protocols and maintained libraries. Decide session versus token behavior from clients and trust model. Specify cookie flags, rotation, expiry, revocation, recovery, MFA, tenant isolation, and role/permission semantics. Test denied paths, cross-tenant access, stale roles, and object-level authorization.

Do not customize cryptographic protocols. Keep provider integration behind an adapter, but keep authorization rules in application-owned code unless a policy engine is an explicit architectural decision.

## Tests And Operations

Test domain rules without infrastructure where useful, API contracts through the real framework boundary, and persistence against the real database engine for important queries and migrations. Add end-to-end coverage for the primary workflow and failure paths. Verify startup, health/readiness, graceful shutdown, timeouts, job retries, migrations, seed safety, backups where in scope, and telemetry. Development fallbacks must fail closed in production.

## Backend Acceptance

The backend starts from documented configuration; migrations are reproducible; API validation and error shapes match the frontend; protected operations enforce authorization; important writes are transactional and retry-aware; tests cover success and denial paths; and local adaptations trace to upstream source.
