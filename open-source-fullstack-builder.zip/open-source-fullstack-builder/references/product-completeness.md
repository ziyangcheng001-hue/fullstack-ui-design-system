# Product Completeness Contract

Apply this contract before calling a branded landing page, product site, dashboard, demo, or campaign experience complete. It prevents a polished hero from masking missing product surfaces.

## Brief-to-Surface Inventory

Translate the brief into a surface inventory before implementation:

| Surface | Required decision |
|---|---|
| Brand/header | Logo, nav destinations, active state, mobile menu, CTA behavior. |
| Hero/first viewport | Named subject/product, value proposition, primary interaction, supporting media, responsive layout. |
| Core showcase | The actual feature, device mockup, 3D scene, diagram, or product artifact and its interaction. |
| Supporting sections | Benefits, workflow, models/features, proof, pricing, docs, FAQ, timeline, or other brief-required modules. |
| Examples/code | Complete runnable snippets, language tabs, copy action, syntax/content, success feedback, and error state where applicable. |
| Device or branded detail | Dynamic island, status bar, phone/laptop shell, logo treatment, or other named visual module must be implemented rather than replaced by an empty card. |
| Navigation/footer | Every visible destination must resolve, scroll to a real section, open a real panel, or be removed. |
| Backend/product behavior | API, form submission, generation, search, auth, persistence, or explicit adapter according to scope. |
| States | Loading, empty, error, permission, success, retry, offline, and reduced-motion/2D fallback where relevant. |

Do not silently omit a surface because it is difficult. Mark it blocked or out of scope in the brief and handoff; do not leave an unlabeled placeholder that looks finished.

## Interaction Minimums

Every primary surface must expose an interaction beyond hover polish. Examples include:

- device controls that change screen content, dynamic island state, or device orientation;
- model/feature cards that switch active content and animate the selected item into focus;
- code-language tabs that replace a complete code sample, preserve selection, and support copy with confirmation;
- pricing or plan controls that update totals, feature comparison, or checkout state;
- timeline/section markers that navigate and synchronize text/media;
- 3D objects that select, resize, orbit, or update a linked detail view;
- forms that submit through a real or documented adapter and expose pending, success, error, and retry states.

At least two primary interactions must be demonstrable in the first working slice. On a branded page, at least one must be visible in the first viewport and at least one must be a content/layout/data change, not just opening a menu.

## Code And Example Completeness

When the page promises an SDK, API, code example, integration, or technical workflow:

- show a complete representative snippet, not only an empty dark rectangle or heading;
- include language switching when multiple languages are implied;
- make copy/download/run actions real and provide confirmation or failure feedback;
- keep displayed code synchronized with the described endpoint, parameters, auth, response, and current product behavior;
- avoid inventing claims that the code cannot perform.

## Visual Continuity And Drift

Choose typography, font loading, font metrics, tokens, and component primitives once in the execution brief. Load the same font stack and token file across every section. Do not allow later sections to silently switch to browser serif defaults, a different heading family, arbitrary colors, or a new radius/shadow system. If a display face is intentionally different, document its role and apply it consistently.

Run a visual continuity pass across the full page at the same viewport and at a narrow viewport. Reject sudden changes in font, line-height, color temperature, border treatment, radius, density, or animation language unless they are a deliberate, documented section transition.

## Browser And Native Chrome

Inspect the complete source and built asset structure, not only screenshots from an isolated section. The browser-native right scrollbar rules, default form controls that conflict with the design, missing focus treatment, and broken deep links are release blockers when the brief asks for a polished product experience. Browser runtime and manual interaction checks are outside this skill unless explicitly requested; preserve native semantics while styling controls and scroll navigation intentionally.

## Completion Gate

The product is complete only when every brief-required surface is present, non-placeholder, connected to its intended interaction or destination, visually consistent, and covered by the available tests and browser evidence. “The hero looks good” is not a completion criterion.
