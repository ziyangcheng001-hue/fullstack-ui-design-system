# Mandatory Chinese Copy And Punctuation Contract

Apply this contract according to the grammatical role of each visible Chinese string. Complete sentences need punctuation; short interface tokens usually do not.

## Required Rule

Complete Chinese sentences and sentence-like explanatory copy end with context-appropriate Chinese punctuation. This includes hero descriptions, body copy, instructions, helper text, validation, alerts, toasts, empty/loading/status explanations, and sentence-like headings or captions.

Do not force terminal punctuation onto short UI tokens: navigation labels, tabs, breadcrumbs, menu items, table headers, short buttons or links, badges, chips, field labels, short placeholders, noun-only tooltips, standalone card titles, metadata keys, brand/product names, pure values/dates/versions/code identifiers, and icon-only controls. Add punctuation only when one of these is written as a complete sentence, question, or instruction.

Use Chinese full-width punctuation for Chinese sentences. Use a full stop for neutral sentences, an exclamation mark for genuine emphasis or success, a question mark for questions, and a colon when introducing a value or list. Keep sibling items grammatically and visually consistent. Navigation such as 首页, 方法, 时间线, 真实反馈 and short commands such as 开始模拟 normally remain unpunctuated.

## QA Gate

Enumerate rendered Chinese strings in initial, loading, empty, error, success, modal, menu, tooltip, and mobile states. Flag complete sentences without punctuation and short UI tokens with unnatural forced punctuation. Inspect desktop, 320px mobile, and 200 percent zoom for missing punctuation, stranded punctuation, and one-character orphan lines. Fix and re-render.

The build is unfinished while complete sentences lack punctuation or short interface tokens contain arbitrary punctuation.
