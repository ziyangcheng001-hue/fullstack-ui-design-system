# Frontend Capability Audit

Use this audit for every substantial frontend build or redesign. The user does not need to name each area. Inspect all areas, implement those the product needs, explicitly preserve those already handled, and omit irrelevant capabilities without adding speculative dependencies.

## Always Inspect

### Interaction Density

- Make the primary workflow richly interactive where it helps: hover, focus, pressed, selected, expanded, dragged, loading, success, error, undo, and keyboard states should be intentional.
- Every interactive affordance needs a clear hit target, feedback, cancellation or recovery path, and an equivalent keyboard/touch behavior.
- Prefer progressive disclosure, inline editing, command/search surfaces, contextual menus, drag/resize where appropriate, optimistic feedback, and reversible actions over decorative motion.
- Do not make the interface busy by default. Interaction density follows task frequency and user intent; critical actions stay easy to discover and predictable.
- For each primary page, complete the interaction contract in [interaction-contract.md](interaction-contract.md) before calling the page finished.
- If no visual direction is specified, complete the style comparison in [style-diversity.md](style-diversity.md) before choosing a template or starter.

### Product Structure

- Information architecture, route hierarchy, page titles, breadcrumbs where depth warrants them, and reliable back/forward behavior.
- Global navigation, local navigation, search/filter state, deep links, and recoverable URLs for important views.
- Primary, secondary, destructive, and bulk actions with clear priority and confirmation proportional to risk.
- Complete workflows rather than isolated screens: entry, progress, success, cancellation, failure, retry, and return path.

### Layout And Responsive Behavior

- Mobile, tablet/intermediate, desktop, wide desktop, portrait/landscape, touch and pointer input.
- Stable page shell, content widths, grids, sidebars, drawers, sticky regions, safe areas, virtual keyboard, zoom, and long localized content.
- Container-aware components and sensible reflow; avoid merely shrinking desktop screens.
- Tables and dense data need explicit small-screen behavior: priority columns, horizontal scrolling, stacked rows, or alternate views.

### Visual System

- Semantic colors, typography roles, spacing, borders, radii, elevation, density, opacity, z-index, and motion tokens.
- Light/dark/high-contrast themes only when required or already supported; persist user preference and respect system preference.
- Font loading, fallback metrics, numeric alignment, code/monospace roles, truncation, wrapping, and localization expansion.
- One primary icon family, documented exceptions, stable optical sizes, accessible labels, and state variants.
- Illustrations, photos, charts, maps, video, and audio must have a product purpose, correct licensing, responsive treatment, and accessible alternatives.
- For rounded interfaces, define a radius hierarchy and keep it consistent across controls, containers, overlays, and media. Rounded does not mean every surface is a floating card.

### Components And Interaction

- Buttons, links, menus, tabs, accordions, dialogs, popovers, tooltips, toasts, drawers, command/search surfaces, pagination, and selection behavior as needed.
- Forms: labels, descriptions, required/optional signals, input modes, autocomplete, masks only when helpful, validation timing, async validation, file uploads, unsaved changes, and error summary/focus.
- Data display: tables, cards only when appropriate, lists, trees, timelines, charts, comparisons, sorting, filtering, grouping, pagination/virtualization, export, and empty values.
- Editing: optimistic or pessimistic strategy, autosave/manual save, dirty state, conflicts, undo, drafts, destructive confirmation, and recovery.
- Direct manipulation: drag/drop, resize, swipe, keyboard equivalents, touch targets, edge scrolling, and cancellation.

### States And Feedback

- Initial loading, local loading, background refresh, skeleton/spinner/progress selection, optimistic state, queued work, and long-running operations.
- Empty, zero-results, first-use, partial data, stale data, offline, reconnecting, rate-limited, permission denied, not found, validation error, server error, timeout, maintenance, and unsupported-browser states where applicable.
- Success, warning, info, destructive, and undo feedback with appropriate persistence; toasts must not carry critical information alone.
- Animations for navigation, view replacement, disclosure, list/layout change, status, icon state, loading, and direct manipulation according to [animation.md](animation.md).

### Accessibility

- Semantic landmarks/headings, accessible names/descriptions, keyboard order, visible focus, skip navigation, focus trapping/restoration, and screen-reader announcements.
- Contrast, color independence, zoom/reflow, text spacing, reduced motion, reduced transparency where relevant, captions/transcripts, alt text, and target size.
- Native semantics first; ARIA only where needed. Test disabled versus readonly behavior and error association.
- Complex widgets follow established keyboard patterns. Mouse-only or hover-only workflows are defects.

### Performance And Resilience

- Appropriate rendering strategy, client/server boundaries, hydration cost, code splitting, route/data prefetch, caching, request cancellation, retry/backoff, and offline behavior where warranted.
- Core Web Vitals, layout stability, image sizing/formats, responsive images, font subsetting/loading, third-party scripts, bundle budgets, animation frame health, and memory cleanup.
- Progressive enhancement for critical tasks; meaningful fallback if JavaScript, animation, media, or a third-party service fails.
- Browser support derived from the audience, with feature detection and tested fallbacks rather than user-agent guesses.

### Security And Privacy In The UI

- Prevent unsafe HTML injection, open redirects, accidental secret exposure, sensitive data in URLs/logs/storage, clickjacking where relevant, and untrusted file preview risks.
- Treat client validation as usability only; backend remains authoritative.
- Permission-aware UI must not imply that hidden controls provide security.
- Consent, tracking, clipboard, camera, microphone, location, notifications, and external embeds require clear purpose and appropriate permission timing.

### Quality And Maintainability

- Component ownership and boundaries, semantic tokens, typed props/contracts, dependency discipline, dead demo removal, consistent naming, and no duplicated competing primitives.
- Unit/component tests for meaningful logic, integration tests for complex interactions, and end-to-end coverage for primary workflows.
- Visual regression where the repository supports it; browser QA across representative viewport/input/theme combinations.
- Developer and user-facing diagnostics must be actionable without leaking private information.

## Inspect When Product-Relevant

- Authentication UI: sign-in, sign-up, passwordless/OAuth, MFA, recovery, verification, session expiry, device/session management, and account deletion.
- Internationalization: locale routing, translation extraction, date/time/number/currency/plural rules, RTL, language switch, and content fallback.
- SEO and sharing: metadata, canonical URLs, robots/sitemaps, structured data, social previews, semantic content, and status codes. Do not force SEO work onto private operational apps.
- PWA/offline: manifest, install experience, service-worker update lifecycle, caching boundaries, offline mutations, background sync, and notification permission. Add only when it improves the product.
- Commerce: price clarity, tax/shipping states, cart persistence, payment handoff, duplicate-submission protection, receipts, refunds, and accessible checkout.
- Real-time/collaboration: connection state, presence, optimistic concurrency, conflicts, ordering, unread markers, reconnection, and notification policy.
- Content systems: rich text, markdown, sanitization, previews, drafts, revisions, media library, moderation, and publishing workflow.
- Maps/charts/canvas/3D: keyboard/table alternatives, responsive sizing, performance budgets, input modes, empty/loading states, and reduced-motion fallback.
- File operations: type/size validation, progress, cancel/retry, resumability, preview, scanning status, download naming, and retention disclosure.
- Printing/export: print stylesheet, page breaks, headers/footers, confidential content, CSV/PDF semantics, and large-export progress.
- Multi-window, embedded, extension, kiosk, TV, or native-webview contexts when the delivery environment requires them.

## Open-Source Reference Search

For each relevant capability, search the existing project first, then actually inspect official framework ecosystems, accessible headless primitives, mature design systems, and maintained reference applications. Evaluate complete reference frontends for workflow and composition, not only individual components. Record the URLs inspected and the specific pattern adopted. Trace every copied implementation and asset to its canonical source and exact license. If a site cannot be opened, mark it unverified instead of implying it was used.

Useful discovery categories include accessible primitives, application shells, admin/operations dashboards, commerce flows, authentication screens, data tables, form systems, charts, editors, uploaders, calendars, command palettes, notification centers, onboarding, settings, error pages, and responsive navigation. Select references that match the product domain and density.

## Scope Rule

Completeness means no relevant category is forgotten; it does not mean every category becomes a feature. Do not add dark mode, PWA, charts, dashboards, animation libraries, authentication providers, analytics, or other capabilities without a product need. Record important omissions only when they remain a real risk or an explicit future decision.
