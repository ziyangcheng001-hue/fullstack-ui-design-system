# Frontend System

Research and implement the entire interface as one system: information architecture, layouts, components, typography, color, icons, motion, responsive behavior, accessibility, and product states.

Before editing a substantial frontend, read [frontend-capabilities.md](frontend-capabilities.md) and audit the full product surface. This prevents unmentioned but necessary areas such as loading, responsive behavior, form errors, accessibility, localization, performance, privacy, and test coverage from being missed.

## Establish The Visual Direction

Before choosing a component library, identify the audience, usage frequency, content density, brand constraints, primary workflows, and target devices. Derive a compact direction with typography roles, semantic color tokens, spacing/radius/border/elevation rules, page shell and breakpoints, interaction states, and reduced-motion behavior.

Use reference products to understand composition and interaction, then restyle to the product. Do not assemble unrelated beautiful sections or clone another product's identity.

## Candidate Sources

These are discovery starting points, not mandatory dependencies. Re-verify project status and license before use.

### Icons

- [Lucide](https://lucide.dev) — broad, consistent outline set; useful default fallback.
- [Phosphor Icons](https://phosphoricons.com) — multiple weights and fill variants.
- [Iconoir](https://iconoir.com) — restrained outline system.
- [Tabler Icons](https://tabler.io/icons) — large SVG catalog.
- [Heroicons](https://heroicons.com) — compact outline and solid families.
- [Iconify](https://iconify.design) — aggregation layer; verify the license of the underlying icon set.

When the user names Morphicons or another specific morphing icon source, locate its canonical project first and confirm its API and license. Use it as the preferred animated-icon layer only if it clears those checks. Otherwise reproduce the interaction with licensed SVG paths or the selected icon set; do not invent a dependency with a similar name.

Choose one primary icon family. Match stroke width, optical size, cap/join style, and fill behavior. Use icons for familiar commands, add accessible names and tooltips where meaning is not obvious, and hide decorative icons from assistive technology.

### Motion

- [Motion](https://motion.dev) — component and layout animation for React or JavaScript.
- [Anime.js](https://animejs.com) — timelines, SVG, and coordinated micro-interactions.
- [AutoAnimate](https://auto-animate.formkit.com) — low-configuration layout transitions.
- [Lottie Web](https://github.com/airbnb/lottie-web) — playback for separately licensed animation assets.
- Native CSS and the [Web Animations API](https://developer.mozilla.org/docs/Web/API/Web_Animations_API) — preferred when behavior is simple.

Motion must communicate causality, continuity, state, or hierarchy. Keep micro-interactions brief, animate transform/opacity when possible, prevent layout shift, and make every nonessential animation respect prefers-reduced-motion. Do not add multiple animation runtimes without a demonstrated need.

For detailed rules covering route/view transitions, loading feedback, timing, icon morphing, motion references, accessibility, and performance, read [animation.md](animation.md).

### Components And Style

- [Radix Primitives](https://www.radix-ui.com/primitives) — accessible headless interaction primitives.
- [shadcn/ui](https://ui.shadcn.com) — editable component source and page examples; inspect each dependency it brings.
- [React Aria Components](https://react-spectrum.adobe.com/react-aria/components.html) — accessibility-focused behavior.
- [Headless UI](https://headlessui.com) — unstyled accessible components.
- [Open Props](https://open-props.style) — CSS design tokens.
- [Tailwind CSS](https://tailwindcss.com) — utility styling when it matches the repository.

Prefer headless primitives when the product needs a distinct visual identity. Prefer an existing project design system when present. Never introduce a framework migration solely because this list mentions it.

### Complete Frontend References

- [shadcn/ui Examples](https://ui.shadcn.com/examples) and [Blocks](https://ui.shadcn.com/blocks) — page composition and product states.
- [Radix Themes](https://www.radix-ui.com/themes) — coherent application surfaces.
- [React Aria examples](https://react-spectrum.adobe.com/react-aria/examples/) — accessible interaction patterns.
- [PatternFly](https://www.patternfly.org) — dense enterprise workflows and documented patterns.
- [Carbon Design System](https://carbondesignsystem.com) — application structure and accessibility guidance.
- [Material Design 3](https://m3.material.io) — interaction and responsive guidance.

Use these to study whole-screen relationships: navigation, filters, tables, forms, detail views, settings, empty states, and responsive collapse. Confirm the license of copied implementation separately from design documentation.

## Implementation Rules

- Centralize semantic tokens; avoid hard-coded colors and one-off spacing.
- Build stable layouts for long content, localization, zoom, loading, and validation messages.
- Use semantic HTML and real controls. Preserve focus through dialogs, menus, route changes, and async updates.
- Render loading, empty, partial, stale, permission-denied, validation, offline, and server-error states where relevant.
- Keep server data, URL/search state, form state, and ephemeral UI state distinct.
- Optimize images, fonts, code splitting, and client boundaries in sympathy with the framework.
- Perform visual QA at a narrow mobile and representative desktop viewport; add intermediate widths for complex layouts.

## Frontend Acceptance

The main workflow works with mouse and keyboard; visible focus remains clear; headings and landmarks are sensible; text and controls do not overlap; icons are consistent; motion does not block input; reduced motion works; forms expose labels and errors; network states are intentional; and unused demo sections are removed.
