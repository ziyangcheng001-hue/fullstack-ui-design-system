# Execution Brief And Evidence Contract

This contract makes the skill repeatable. It separates “the model knows the rules” from “the delivered frontend actually follows them.” Use it for every substantial build or redesign.

## Preflight Brief

Before coding, create a short project-local brief, such as `DESIGN_EXECUTION.md`, containing:

| Field | Required content |
|---|---|
| Product and audience | What is being built, for whom, and the primary task. |
| Named subject | Person/product/place/event that must appear in the first viewport, or “none.” |
| Style candidates | At least three materially different families and the canonical URLs inspected. |
| Selected direction | Palette, typography, shape/radius, composition, material, and why it fits. |
| Core interactions | One or more per primary page, with triggers and meaningful state changes. |
| Motion plan | Required view, component, async, direct-manipulation, and scroll animations. |
| 3D plan | Scene purpose, clickable target, linked state, performance budget, 2D fallback, or “none.” |
| Content plan | Required media, text hierarchy, Chinese punctuation policy, and localization risks. |
| Backend contract | API/data/auth boundary for the first end-to-end slice. |
| QA plan | Browser viewports, input modes, reduced motion, slow network, and failure paths. |

Do not proceed with placeholders such as “add animations later,” “use a modern template,” “3D hero,” or “make it interactive.” Name the object, trigger, state, and evidence target.

## Build-Time Traceability

While implementing, keep these records close to the project:

- `SOURCE_RESEARCH.md` or an existing source ledger, with actual URLs opened, findings, license evidence, selected/rejected decisions, and copied/adapted paths;
- the interaction contract for each primary page;
- the motion plan with the exact control or scroll range that triggers each animation;
- asset provenance and fallback for named subjects;
- known omissions and why they are irrelevant or deferred.

If a source cannot be opened, mark it unverified and do not claim it informed the implementation. If a named-subject asset cannot be licensed, state the limitation and label the substitute.

## Final Handoff Format

The final response or project handoff must include these sections, in this order:

1. `实际参考来源` — URLs actually inspected, what each contributed, and whether code/assets were copied, adapted, or only observed.
2. `风格决定` — compared families, selected direction, and product-specific differences from any reference.
3. `真实交互` — each primary page's control, before/during/after/failure states, and the real state it changes.
4. `动画证据` — view, component, async, direct-manipulation, and scroll animations wired in source; identify which are not implemented. Runtime triggering is unverified unless explicitly requested.
5. `主体与素材` — named subject visibility, asset source/license, crop/alt treatment, or explicit limitation.
6. `滚动与导航` — scroll choreography, custom progress/section control, and confirmation that native right scrollbar is hidden without breaking native scrolling.
7. `后端与数据` — API, persistence, auth/authorization, migrations, and tests for the vertical slice.
8. `实现结构` — frontend behavior modules, backend routes/use cases, data adapters, and why the result is not HTML-only.
9. `验证结果` — build, lint/type, unit/integration, and static contract commands, plus runtime/browser behavior marked unverified unless separately requested.

Do not replace these sections with a generic “implemented successfully” summary. A missing section means the build is not evidenced.

## Hard Failure Conditions

Fail the build and continue iterating when any of the following is true:

- the first viewport lacks the named subject or a real primary interaction;
- a visible card, arrow, dot, thumbnail, switch-view control, or 3D object implies interaction but is dead;
- animation evidence contains only hover polish, color changes, shadows, opacity fades, or page-load entrances;
- scroll moves static text while the browser-native right scrollbar remains visible;
- the final report lists links that were not actually inspected;
- the implementation report cannot identify a JavaScript/TypeScript behavior layer or backend boundary when the product requires one;
- Chinese complete sentences lack punctuation, or short navigation tokens have arbitrary forced punctuation;
- requested interaction behavior has no statically inspectable event/state/render path.
- the implementer declares completion solely because files were written, without running the available checks or marking unavailable checks as unverified.
- any available build, lint/type, unit/integration, or browser check was skipped, even when the user did not mention testing.
