# Open-Source Selection

Use this process when discovering libraries, starters, components, assets, or backend services.

## Search Order

1. Existing dependencies and internal components.
2. Official framework ecosystem and documentation.
3. Official source repositories and package registries.
4. Maintainer-owned examples and mature community projects.
5. Galleries and aggregators only for discovery; trace every candidate back to its canonical source.

Search by capability and constraints, not appearance alone. Include the framework, runtime, accessibility requirement, license preference, and the concrete interaction or domain behavior in queries.

## Research Execution Gate

When web or repository access is available, actually open and inspect the canonical pages before selecting a foundation. For each relevant capability, keep a short research record:

| Capability | URLs inspected | Finding | Decision |
|---|---|---|---|

Inspect at least the canonical documentation or demo, source repository/package page, and exact license file for any dependency or copied source. For visual references, inspect the actual page or example and record which interaction, composition, or state informed the implementation. A URL copied from this skill is a starting point, not evidence that it was visited.

When network or browser access is unavailable, say that the candidate is unverified, use only repository-local evidence and already installed dependencies, and do not present external maintenance, license, or feature claims as checked facts. Defer a high-impact dependency or legal decision when verification is required.

## Evidence To Capture

| Field | Evidence |
|---|---|
| Canonical source | Official site, source repository, and package identifier |
| License | Exact license file and, for assets, the asset-specific terms |
| Maintenance | Recent releases/commits, open issue health, maintainer activity |
| Compatibility | Framework/runtime versions, browser/platform support |
| Quality | Tests, documentation, accessibility, security guidance |
| Cost | Bundle/runtime weight, services, migration effort, lock-in |
| Adaptation | What can stay upstream-compatible and what must be wrapped or modified |

Do not use stars as the primary quality signal. A small focused library can be a better dependency than a popular general-purpose one.

## License Gate

Prefer MIT, Apache-2.0, BSD-2-Clause, BSD-3-Clause, ISC, and similarly permissive licenses when they meet the task. Treat GPL, AGPL, LGPL, MPL, source-available licenses, font licenses, icon licenses, stock-media terms, and dual licenses as separate legal cases. Explain the relevant obligation and ask for direction when it may affect distribution, hosted services, proprietary code, or commercial use.

Verify licenses at the exact version or commit used. A project may contain assets, examples, fonts, or subpackages under different terms. Never label something open source solely because its source is visible.

This skill provides an engineering screen, not legal advice. Escalate ambiguous or consequential licensing decisions.

## Reuse Decision

Use a dependency when it supplies complex, well-tested behavior or a maintained standard implementation. Copy and adapt a small component when its API surface is tiny, local ownership is desirable, and the license permits it. Build custom code when the requirement is product-specific, available projects introduce more complexity than they remove, or no candidate clears the quality and license gates.

Prefer wrappers and adapters over editing vendor code. If a fork is necessary, keep the patch narrow, document the upstream commit and reason, and define how upstream security fixes will be tracked.

## Source Ledger

For copied or substantially adapted material, record:

| Component | Upstream URL | Version/commit | License | Local path | Adaptations |
|---|---|---|---|---|---|

Keep required copyright and attribution notices. Record design references when a page closely follows a specific open-source example even if code was not copied.

The final handoff for a researched build should link the inspected pages, summarize the selected and rejected candidates, and state any sources that could not be opened or verified.

## Reject Or Escalate

Reject candidates with unclear provenance, missing license, abandoned critical dependencies, unresolved high-impact security problems, inaccessible core interactions, hidden paid requirements, or a customization model that fights the product. Escalate when a copyleft or source-available license may change distribution obligations.
