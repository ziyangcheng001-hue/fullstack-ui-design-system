# Full-Stack Implementation Contract

This contract prevents a visual prototype from being delivered as a static HTML shell. Apply it unless the user explicitly asks for a static, non-interactive page or a design-only mockup.

## Stack Decision Before Markup

Inspect the repository and identify its actual frontend and backend entry points, scripts, package manager, build tool, runtime, routes, data sources, and test commands. Choose the existing stack when fit. If the project is plain HTML, add a deliberate JavaScript module structure rather than hiding all behavior in inline handlers.

## Required Behavior Layer

Every interactive feature must have:

- a real event source: click, pointer, keyboard, touch, input, drag, scroll, or network event;
- explicit state or a state machine;
- a render/update path that changes DOM, component state, canvas, 3D scene, URL, or data;
- pending, success, failure, cancellation, or recovery behavior when the operation can fail or take time;
- keyboard and touch equivalents;
- cleanup for listeners, timers, observers, animation frames, and resources.

Use JavaScript or TypeScript modules, framework components, or an equivalent behavior layer. CSS alone may style a state, but CSS hover selectors cannot be the implementation of a primary feature.

## Required Frontend/Backend Wiring

When the request involves data, accounts, persistence, generation, search, forms, simulation, or a backend:

1. Define the contract: request, response, error, loading, authorization, and empty shapes.
2. Implement the frontend call through a real API/client boundary.
3. Implement the server route/use case and validation.
4. Connect persistence, external provider, or an explicit deterministic development adapter.
5. Handle network failure, timeout, retry, and stale or unauthorized state.
6. Test the boundary and the primary success and denial paths.

Static arrays, hard-coded result text, fake timers, and click handlers that only swap a class are not substitutes for a backend when backend behavior is in scope. A deterministic mock is allowed only when explicitly documented as a temporary adapter and the real boundary remains implemented or clearly stubbed behind the same contract.

## HTML-Only Failure Conditions

Fail and continue implementation when any of these is true:

- the deliverable contains only `index.html` or only static markup for a requested interactive product;
- JavaScript or TypeScript is absent despite required interactions;
- scripts exist but are not loaded, throw at startup, or expose no real event/state/render path;
- buttons, cards, tabs, switch-view controls, 3D objects, arrows, or section dots do not update meaningful state;
- a backend request is represented by hard-coded data with no API/client boundary;
- loading, success, error, retry, cancellation, or authorization behavior is missing where applicable;
- the implementation has no statically inspectable script/state/render path for requested interactions.

## Required File And Runtime Evidence

The handoff must name:

- frontend entry point and behavior modules or components;
- backend entry point, routes/use cases, persistence, and migrations when applicable;
- the exact commands used to run the app and code checks;
- any development adapter or mock and its replacement plan;
- the source handlers and state/render paths for each major behavior;
- console/runtime errors found and fixed.

For a plain HTML project, the minimum acceptable structure for an interactive page is an external script module such as `app.js` plus any focused modules it needs, loaded with `type=module`, with real event listeners, state updates, and browser-tested behavior. Inline script is acceptable only for a tiny isolated demo and must still satisfy the same contract.

## Acceptance

Run the available build, lint/type, unit/integration, and static contract checks. Browser runtime and manual interaction testing are not required by this skill. Still require a statically inspectable event/state/render path for every requested interaction; source-only declarations without a connected path remain a failure.

Do not report completion immediately after writing files. Completion requires the available code checks and product-completeness review. Record browser behavior as unverified unless the user separately requests browser testing.
