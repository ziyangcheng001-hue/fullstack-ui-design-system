# Full-Stack Example

This example illustrates the decision shape and is not a required stack.

## Example Brief

Build an authenticated operations dashboard with a searchable table, record detail/edit flow, audit history, and role-based access.

## Capability Map

| Capability | Reuse candidate | Local adaptation |
|---|---|---|
| Dialogs, menus, tabs | Existing design system or accessible headless primitives | Product tokens, density, content, focus behavior |
| Icons | One permissive icon family | Semantic mapping and optical sizing |
| Layout motion | Native CSS or one motion library | Reduced-motion and async state transitions |
| Data table | Existing framework component or mature table core | Columns, URL filters, permissions, empty/error states |
| API | Existing server framework | Product-specific contracts and error codes |
| Authentication | Maintained protocol/library/provider | Session policy and account lifecycle |
| Authorization | Application-owned policy | Roles, ownership, tenant boundaries |
| Persistence | Existing database and migration tool | Schema, constraints, indexes, transactions |

## Thin Vertical Slice

Implement one view-record flow first: define identifier, response schema, permission failure, not-found error, and stale-data behavior; add query and object-level authorization tests; expose the API with boundary validation; build list-to-detail loading, empty, error, denied, and success states; confirm URL navigation, keyboard focus, responsive behavior, and a real end-to-end request.

Then extend the same contract conventions to search, edit, audit history, and role management.

## Completion Checklist

- Foundations have canonical sources and verified licenses.
- Existing architecture is followed unless a justified change was accepted.
- Tokens, icons, motion, components, and page composition form one visual system.
- Mobile/desktop layouts, keyboard use, focus, reduced motion, and network states were checked.
- Frontend and backend share or validate data contracts.
- Authentication, object authorization, validation, transactions, and constraints cover main risks.
- Migrations, environment variables, startup, and seed behavior are documented.
- Focused tests cover primary success and denial paths.
- Copied/adapted code and assets are recorded with source, version, license, path, and changes.
- Unused starter material and redundant dependencies are removed.
