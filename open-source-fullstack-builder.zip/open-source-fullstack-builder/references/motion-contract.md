# Mandatory Motion Contract

Apply this contract to every substantial frontend unless the user explicitly requests a motionless interface.

## Required Categories

A multi-view product implements all four categories; a small single-purpose page implements at least three.

1. View continuity: route/view replacement, master-detail expansion, shared element, split-pane, canvas, or camera transition.
2. Component transformation: drawer, dialog, disclosure, reorder, resize, inline editor, filter result, or selection with visible geometry/layout change.
3. Async feedback: real pending animation followed by distinct success, failure, retry, or undo tied to an actual operation.
4. Direct manipulation: drag, swipe, scrub, pan, zoom, orbit, resize, morphing icon, or user-controlled movement that changes product state.

Each primary page implements at least one transition involving direction, distance, geometry, layout, shape, shared-element continuity, or direct manipulation. Opacity may support it but cannot be the only animated property.

## Does Not Count

- Hover color, border, shadow, glow, lift, scale, tilt, or cursor-follow effects.
- Pure fade-in/fade-out or crossfade with no spatial, geometric, layout, or state relationship.
- One-time hero entrance, looping decoration, marquee, shimmer, particles, or auto-rotating 3D.
- CSS transitions present in source but not triggered during the verified workflow.
- Timers that imitate real loading or success.

## Implementation And Evidence

For every required category, define the trigger, start state, animated spatial or shape change, end state, interruption behavior, and reduced-motion equivalent. Wire motion to real state, data, selection, URL, layout, camera, or object changes. Make repeated input interruptible and prevent stale completion.

Trace each animation from trigger through state, timeline, and rendered target in source. Confirm start, in-motion, end, interruption, and reduced-motion branches are represented. Browser execution is not required unless separately requested; a transition declaration with no connected trigger/state/render path is still not implemented.

The frontend is unfinished when the only movement is hover polish, opacity-only fading, page-load entrance, decorative looping motion, or static 3D.
