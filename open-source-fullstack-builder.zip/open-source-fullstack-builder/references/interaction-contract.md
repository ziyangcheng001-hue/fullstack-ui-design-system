# Mandatory Interaction Contract

This contract prevents an implementation from satisfying a visual brief with a static mockup. Apply it to every primary page and every major workflow. Secondary informational pages may be simpler, but must still expose intentional navigation and state feedback. The first viewport of the product must expose at least one discoverable core interaction, and the completed build must demonstrate at least two primary interaction paths.

## Non-Negotiable Rule

A page is incomplete if its main interaction is only a hover color, hover shadow, opacity-only fade, a button with no meaningful result, a decorative animation, a static 3D object, or a visual card layout with no stateful behavior. The result must change geometry, layout, content, data, navigation, selection, camera, or object state.

Any element that looks interactive must actually work or be restyled as non-interactive. Cards, thumbnails, arrows, pagination dots, section markers, switch-view controls, navigation labels, and floating objects cannot remain dead decoration when their appearance implies an action.

## Define Before Coding

Write one short contract per primary page:

| Field | Required content |
|---|---|
| User goal | What the user is trying to accomplish. |
| Core interaction | The direct manipulation or decision that makes the page useful. |
| Trigger | Click, drag, keyboard, touch, scroll, upload, shortcut, or network event. |
| Before state | What is visible and actionable initially. |
| During state | What changes while the action is in progress. |
| After state | The new layout, content, selection, camera, data, or navigation. |
| Failure/recovery | Error, cancellation, retry, undo, or conflict path. |
| Accessible equivalent | Keyboard and assistive-technology behavior. |
| Reduced-motion/2D fallback | Equivalent behavior without motion or 3D. |

Do not proceed with only a vague statement such as “add some animations.” Choose the state transition and the user value first.

## Interaction Patterns To Prefer

Choose patterns that fit the product; do not add all of them to every page:

- Master-detail: selecting a row or card updates a persistent detail pane with a shared-element or anchored transition.
- Command surface: keyboard shortcut or visible command button opens searchable actions, with highlighted results and confirmation feedback.
- Direct manipulation: drag, resize, reorder, scrub, pan, orbit, or zoom changes real product state and offers cancel/reset.
- Progressive disclosure: expanding a section reveals real data or controls while preserving context and focus.
- Inline editing: enter, validate, save, cancel, dirty, conflict, and success states are visible without a dead-end modal.
- Live filtering: input updates results with debouncing, pending indication, empty/zero-results state, URL persistence, and clear action.
- Optimistic mutation: the UI updates immediately, shows pending/reconciliation, and exposes undo or a clear recovery path.
- Spatial/3D interaction: an object, scene, map, or diagram can be manipulated and its result is reflected in a 2D summary or data model.
- Multi-step flow: progress, back, validation, resumability, and completion are explicit.

## Implementation Requirements

- Use real state, not a timer that merely changes CSS classes. The state must drive content, layout, data, URL, camera, or selection.
- Keep hit targets stable while feedback changes. Do not make a user chase a moving control.
- Provide loading, success, failure, empty, disabled/denied, and cancellation behavior wherever the operation can take time or fail.
- Make important results persistent enough to understand. Toasts alone are insufficient for destructive, financial, security, or form-validation outcomes.
- Keep animation subordinate to the state change. A transition that can be removed without changing the meaning is decorative and cannot be the only interaction.
- Button color, border, shadow, glow, lift, scale, or opacity changes are polish only. They never count as a core interaction.
- Pure fade-in/fade-out is a fallback or supporting layer only. At least one core transition per primary page must include meaningful spatial, layout, shape, shared-element, or direct-manipulation change.
- Add keyboard and touch equivalents. Pointer-only drag or hover behavior is not an acceptable core path.
- Expose an accessible name, role, current value/state, and announcement for asynchronous results.
- For 3D, bind manipulation to actual data or navigation, supply a 2D fallback, and clean up rendering resources.

## Static Implementation Verification

Use source inspection and repository static/test tooling to verify the contract. Browser runtime and manual interaction testing are not required by default:

1. Locate the trigger and handler.
2. Trace state changes to DOM/component/canvas/3D updates.
3. Trace loading, success, failure, cancellation, and recovery branches.
4. Confirm keyboard, touch, reduced-motion, and fallback branches exist in code.
5. Confirm responsive states are represented in layout rules.

Record static findings in the handoff. Mark runtime behavior as unverified unless the user explicitly requests browser testing; do not claim runtime success from source inspection alone.

### Affordance Coverage

Before delivery, enumerate every apparent interactive affordance in the rendered page: links, buttons, cards, tabs, chips, arrows, dots, thumbnails, 3D objects, drag handles, scroll markers, and keyboard shortcuts. Verify each has a real handler or destination, changes meaningful state or navigation, exposes keyboard focus, and has recovery behavior where failure is possible. Remove dead affordances rather than leaving them decorative.

For card-based switch-view designs, both the card and visible switching control must work, or the card must be clearly styled as a non-interactive preview. Switching updates the active item plus content, indicator, URL, detail panel, camera, or data. A click that only changes color is insufficient.

For a full build, statically trace at least two distinct primary paths, for example:

- open a control and trace the content or layout update;
- manipulate a list, panel, camera, or input and trace the persisted state update;
- submit an operation and trace pending, success, and recovery states.

Do not count scrolling, hovering, or opening a static menu as one of the two paths unless it causes a meaningful product state change.

## Minimum Acceptance

For each primary page, define at least three meaningful interaction affordances when the page has multiple sections or showcase modules. At least one must change real content, layout, data, URL, camera, or navigation; at least one must be a spatial, direct-manipulation, progressive-disclosure, or state-transition interaction. If the page contains 3D, one of the three must be a clickable 3D target linked to another object's size, position, material, camera, detail panel, timeline, or data. The handoff must name each interaction and its initial, in-progress, completed, and failure/recovery states. A screenshot of a static page is not evidence of completion.

Reject as incomplete:

- static cards with only hover shadows;
- buttons whose only feedback is color, border, glow, scale, opacity, or shadow;
- opacity-only fades used as the main page or component transition;
- cards, dots, arrows, or switch-view controls that appear clickable but have no real handler or destination;
- buttons that do not change state or produce a real result;
- loaders that never correspond to an async operation;
- 3D that cannot be manipulated or inspected;
- animations that play automatically but do not explain a state;
- fake interactivity implemented only with delayed timers;
- interaction that works with a mouse but not keyboard or touch.
