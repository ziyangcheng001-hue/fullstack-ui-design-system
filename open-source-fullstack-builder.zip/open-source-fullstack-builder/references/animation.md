# Interface Animation

Use motion to explain state changes, preserve spatial context, acknowledge input, and make waiting legible. Do not animate merely to decorate an otherwise complete interface.

## Choose Motion By Event

| Event | Preferred treatment | Use when | Avoid when |
|---|---|---|---|
| Route or view change | Shared shell remains stable; old content exits subtly while new content enters | The destination is related and continuity helps orientation | Navigation is already instant, the views are unrelated, or motion delays reading |
| Master to detail | Shared element, anchored expansion, or directional slide | The source object and destination clearly correspond | Geometry is unstable or the relationship would be misleading |
| Tabs and segmented views | Short crossfade or directional content shift; indicator moves | Adjacent peer views change in place | Each tab triggers slow data loading; show state separately |
| Dialog, popover, menu | Fade plus small scale/translation from its trigger | Revealing a temporary layer tied to a control | Large spring overshoot, long entrances, or focus arriving before content is usable |
| Accordion/disclosure | Animate measured height/clip and opacity without shifting unrelated controls unpredictably | Content is locally revealed | Large pages where repeated height animation causes jank |
| List insert/remove/reorder | Layout animation with stable keys | The user caused or needs to understand the change | Large virtualized lists unless the library explicitly supports it |
| Save/delete/action result | Immediate pressed state, then local progress and success/error feedback | The operation is asynchronous | Celebratory animation for routine actions or hiding errors behind animation |
| Drag, swipe, resize | Direct manipulation tracks pointer; release settles with restrained spring | Touch or spatial manipulation is intrinsic | Keyboard users lack equivalent controls or reduced-motion fallback |
| Scroll-linked motion | Minimal progress, reveal, or spatial explanation | Scroll position genuinely controls a narrative or tool | Ordinary product pages, critical content, or effects that cause motion sickness |

## Loading And Waiting

Choose feedback from expected duration and known layout:

- Under roughly 100 ms: show no loader; prevent flicker.
- Around 100-500 ms: retain current content and show a subtle local pending state when useful.
- Longer or uncertain: show a stable skeleton for known content geometry, or a compact spinner/progress indicator when geometry is unknown.
- Determinate operations: use real progress when the backend can report meaningful completion. Never fake a percentage.
- Background refresh: keep stale content visible, mark it as refreshing, and avoid replacing the whole screen with a loader.
- Button submissions: keep the button width stable, expose a busy state, prevent accidental duplicate submission, and preserve the label or accessible operation name.
- Full-page startup: reserve the final layout early. Prefer server rendering, streaming, or cached content over elaborate loader animation.
- Empty results are not loading states. Timeouts, offline state, permission failure, validation failure, and server errors need distinct recovery paths.

Skeletons should match real content shapes, avoid excessive shimmer, stop when content is ready, and be suppressed or simplified under reduced motion. Do not use skeletons when the final layout is unpredictable or when a spinner communicates the operation more honestly.

## Timing And Easing

Start with a small motion-token set and tune it in the real product:

- Immediate feedback: about 80-140 ms.
- Small component transitions: about 140-220 ms.
- Panels, dialogs, and view changes: about 180-320 ms.
- Larger spatial transitions: rarely beyond 400 ms unless the user directly controls them.

Exits are generally a little faster than entrances. Use ease-out for entrances, ease-in for exits, and symmetric easing for continuous movement. Springs suit direct manipulation and layout settling, not every opacity change. Stagger only when sequence conveys hierarchy; keep the total delay short and cap item count so large lists do not become slow.

These are starting ranges, not fixed laws. Input must remain responsive, content must become readable promptly, and repeated workflows should feel faster than first-run demonstrations.

## Page Transition Contract

- Keep persistent navigation, headers, and global tools visually stable.
- Animate only the region that changes. Do not fade the entire application to white or black between routine routes.
- Start the destination only when its initial geometry is known enough to avoid a second jump.
- Preserve scroll intentionally: reset for new top-level pages, retain for back navigation, and use anchored restoration for master-detail flows.
- Move focus to the destination heading or meaningful region after navigation without fighting pointer users.
- Cancel or finish obsolete transitions when navigation changes quickly.
- Do not block browser back/forward, deep links, or route errors on animation completion.
- With reduced motion, replace spatial travel and parallax with an instant change or very short opacity transition.

## Icon Animation

Use morphing icons only when the two states are semantically paired, such as play/pause, menu/close, expand/collapse, volume states, or favorite toggles. The hit target must not move or resize. Preserve a stable accessible name or announce the resulting state; the animation itself is never the only signal.

Prefer the chosen primary icon family. If Morphicons or another morphing set is requested, verify its canonical source, exact license, framework support, path compatibility, and reduced-motion behavior. When paths cannot morph cleanly, crossfade or rotate licensed icons rather than forcing distorted interpolation.

## Implementation Selection

1. Use CSS transitions/keyframes for simple hover, focus, disclosure, spinner, and opacity/transform effects.
2. Use the Web Animations API when imperative control, cancellation, or sequencing is needed without a framework runtime.
3. Use Motion for React/component layout transitions, gestures, presence, and shared layout when it fits the existing stack.
4. Use Anime.js for coordinated timelines or SVG path work that CSS cannot express cleanly.
5. Use AutoAnimate for simple list/layout changes only after checking control, accessibility, virtualization, and bundle tradeoffs.
6. Use Lottie only for a separately designed asset whose license, file size, renderer, fallback, and reduced-motion behavior are acceptable.

Use one general animation runtime at most unless a concrete feature requires another. Lazy-load large animation assets and keep critical interaction independent of animation initialization.

## Reference Sites

Study principles and behavior, then implement in the product's own visual language. Verify licenses before copying code or assets.

- [Material Design Motion](https://m3.material.io/styles/motion/overview) — hierarchy, easing, duration, and transition patterns.
- [Apple Human Interface Guidelines: Motion](https://developer.apple.com/design/human-interface-guidelines/motion) — continuity, feedback, and restraint across interaction modes.
- [Carbon Motion](https://carbondesignsystem.com/elements/motion/overview/) — productive versus expressive motion and tokenized timing.
- [Fluent 2 Motion](https://fluent2.microsoft.design/motion) — transitions, duration, easing, and accessibility.
- [Atlassian Design System Motion](https://atlassian.design/foundations/motion/) — practical product-interface motion guidance.
- [Motion examples](https://motion.dev/examples) — implementation patterns for layout, gestures, and presence.
- [Anime.js documentation](https://animejs.com/documentation/) — SVG and timeline techniques.
- [MDN View Transition API](https://developer.mozilla.org/docs/Web/API/View_Transition_API) — native document and same-document transitions; verify browser support and fallback.
- [web.dev View Transitions](https://web.dev/view-transitions/) — progressive-enhancement patterns and performance considerations.
- [Nielsen Norman Group: Response Times](https://www.nngroup.com/articles/response-times-3-important-limits/) — choosing feedback from perceived wait duration.

Use polished commercial products only as observational references, not code sources. Inspect how Linear, GitHub, Stripe, Vercel, Apple, and Notion preserve context, handle optimistic feedback, and keep repeated workflows restrained; do not clone their branding or assume their implementation is open source.

## Accessibility And Performance Gate

- Honor prefers-reduced-motion at the CSS and JavaScript layers. Stop autoplay, parallax, large zooms, and continuous decorative motion; provide an equivalent state change.
- Animation must not trap focus, reorder the accessibility tree unexpectedly, delay announcements, or conceal controls.
- Avoid flashes and rapid contrast changes. Never communicate status through movement alone.
- Prefer transform and opacity, but verify text rendering and compositing. Do not add will-change globally.
- Measure on representative low-power/mobile hardware. Check long tasks, dropped frames, layout shift, memory, and animation cleanup after unmount/navigation.
- Pause offscreen or hidden continuous animation and respect page visibility.

## Animation Acceptance

Verify route transitions, dialogs, disclosures, list changes, submissions, loading, success/error feedback, rapid repeated input, browser back/forward, interrupted navigation, reduced-motion mode, keyboard/focus behavior, mobile viewport behavior, and a slow-network simulation. Remove any animation that delays task completion, causes layout instability, lacks a state purpose, or cannot degrade cleanly.

For a page longer than one viewport, at least two text or content blocks must reveal, shift, transform, or transition from scroll progress or section entry. A static scroll with only a progress indicator does not satisfy the requirement.
