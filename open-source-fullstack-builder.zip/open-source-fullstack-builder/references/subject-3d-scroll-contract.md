# Subject, 3D, Scroll, And Surface Contract

Apply this contract to visual frontends with named subjects, 3D scenes, or multiple viewport sections.

## Named Subject

If the brief names a person, product, place, company, or event, show that subject or its unmistakable primary artifact in the first viewport. For a person such as Elon Musk, use a recognizable portrait, approved press image, licensed video, or clearly credited silhouette/illustration when a photograph cannot be licensed. Do not replace the subject with a generic planet, gradient, abstract sphere, code panel, or anonymous avatar.

Inspect the canonical asset source, creator, exact license, attribution, resolution, crop rights, and local fallback. If no suitable licensed asset exists, state the limitation and use an intentional labeled alternative.

## Clickable 3D

Every meaningful 3D scene exposes at least one discoverable click/tap target. The action changes real state, such as selecting a red sphere so it enlarges while another shrinks, focusing a planet and updating a detail panel, or changing geometry/material/data through a control. The transition is smooth, continuous, and interruptible; use eased or spring scale/position/material transitions rather than an instant class swap. Keep hit targets stable, show selection, provide keyboard/focus equivalents, and include a 2D list or detail panel.

Reject 3D that is only a static decoration, auto-rotation, parallax background, or screenshot with no user-controlled state change.

## Scroll Choreography

For pages longer than one viewport, map scroll progress to section reveals, per-line or per-block text motion, subject/media movement, camera orbit/zoom, timeline progress, or scene morphing. Use IntersectionObserver or scroll-linked timelines with a non-JavaScript fallback. Keep a persistent progress rail, section marker, or custom navigator that reflects the current section and supports keyboard activation. Avoid scroll hijacking and preserve wheel, keyboard, touch, and assistive-technology scrolling.

Scrolling that only moves the document, shows a browser scrollbar, or leaves all text static does not satisfy this contract.

Every visible section marker, dot, arrow, card, or switch-view affordance in the scroll experience must be wired to its section or state. Clicking it changes the active section, selected content, camera, detail panel, URL, or data. Decorative markers must not look like controls.

## Custom Scroll Navigation

On a designed page, the browser's native right-side scrollbar must not remain visibly exposed. Hide it cross-browser while preserving the scroll container and native wheel, touch, Page Up/Down, Home/End, Space, focus, and assistive-technology behavior. Use scrollbar-width: none for Firefox and a zero-size or display-none ::-webkit-scrollbar rule for Chromium/WebKit; do not disable overflow or replace scrolling with wheel-event hijacking.

Provide a rounded custom rail, thumb, progress indicator, or section dots with an accessible label and current position. It may control scrolling but must not be the only way to reach content. Keep it inset from the viewport edge, visually integrated with the radius system, and large enough for touch when interactive. Test high contrast, zoom, reduced motion, coarse pointers, keyboard scrolling, and nested scroll regions. Any screenshot showing the browser-native right scrollbar fails visual QA.

## Rounded Surface QA

Use a radius hierarchy across controls, cards, media, dialogs, and navigation. Pair rounded shapes with consistent clipping, border, shadow, spacing, and focus treatment. Avoid random pills, nested rounded cards, inconsistent radii, and clipped text, focus rings, 3D canvases, or hit targets.

## Static Evidence Gate

Without requiring browser execution, inspect source for the named subject asset in the first viewport, a clickable 3D target with linked state changes, scroll-linked text/scene choreography across at least three sections, custom section navigation handlers, and cross-browser native-scrollbar hiding rules. Runtime behavior remains unverified unless the user explicitly requests browser testing; static screenshots alone do not prove behavior.
