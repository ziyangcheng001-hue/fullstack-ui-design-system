# Interaction, 3D, Rounded UI, And Typography

Use this reference for frontend work when the product benefits from richer interaction or a more tactile visual system. These are quality gates, not permission to add effects without a product reason.

## Interaction-First Design

Design each important workflow as a state machine:

| State | Required behavior |
|---|---|
| Rest | Clear affordance, readable label, stable geometry |
| Hover/focus | Local emphasis without changing layout or hiding information |
| Press/drag | Immediate acknowledgement, pointer capture where needed, cancel path |
| Pending | Stable control size, duplicate submission prevented, meaningful progress |
| Success | Local confirmation and next useful action |
| Error | Specific explanation, recovery action, preserved user input |
| Disabled/denied | Explain why when knowable; never rely on opacity alone |
| Keyboard/touch | Equivalent operation, visible focus, adequate target size |

Favor interactions that reveal structure or reduce work: split panes, resizable panels, sortable/filterable data, inline editing, command palettes, contextual actions, expandable detail, undo, and preview-before-commit. Keep hover-only information supplemental; touch and keyboard users must not lose capability.

Use event feedback in layers: input acknowledgement immediately, local state update next, network confirmation after. Make optimistic updates reversible and reconcile conflicts instead of silently overwriting changes.

## 3D: When And How

Use 3D when depth is part of the product meaning: spatial configuration, product/asset inspection, maps, diagrams, data surfaces, visualization, games, or a deliberate hero interaction. For ordinary forms, tables, settings, and dense operational screens, prefer 2D depth cues unless a specific task benefits from 3D.

### 3D Rules

- Start from a 2D task-complete fallback. The app must remain usable if WebGL, WebGPU, shaders, device motion, or the 3D asset fails.
- Prefer open standards and maintained open-source tooling such as [Three.js](https://threejs.org), [React Three Fiber](https://r3f.docs.pmnd.rs), [Babylon.js](https://www.babylonjs.com), and glTF tooling. Verify exact licenses, asset terms, browser support, and bundle cost.
- Keep the primary scene purposeful and inspectable. Do not put a required interaction inside a decorative 3D card or make text unreadable on a perspective plane.
- Use camera, lighting, scale, and depth consistently. Avoid gratuitous tilt, floating objects, bloom, particles, or parallax that compete with controls.
- Establish performance budgets for triangles, textures, draw calls, memory, frame rate, and startup time. Lazy-load noncritical scenes and dispose geometries, materials, textures, render targets, and event listeners.
- Respect reduced motion and reduced transparency. Disable camera sway, auto-rotation, device-motion response, and large perspective travel when requested.
- Provide keyboard navigation, semantic labels, focusable controls, and a 2D list/table/summary for spatial data. Do not communicate state by depth or color alone.
- Test resize, orientation change, low-power/mobile hardware, context loss, scroll containment, pointer capture, and browser back/forward.

Use CSS 3D for small decorative transforms or card flips when it is cheaper and more accessible than a scene. Use a 3D engine only when scene graph, camera, lighting, geometry, or real spatial manipulation is necessary.

## Rounded Visual Language

Use a deliberate radius scale rather than applying a large radius everywhere:

- Small controls and fields: subtle radius that preserves a crisp target.
- Standard controls and compact surfaces: medium radius.
- Sheets, dialogs, media, and primary feature surfaces: larger radius only when the shape supports hierarchy.
- Avoid nested rounded containers, excessive pills, and cards inside cards.

Pair rounded geometry with restrained borders, shadows, spacing, and focus rings. Keep hit areas stable. Full-width sections should remain unframed layouts; cards are for repeated items, dialogs, and genuinely framed tools.

## Typography And Chinese Line Breaking

- Define display, heading, body, label, caption, numeric, and code roles with explicit size, weight, line-height, and fallback fonts.
- Never allow a Chinese line to end with one isolated character when a reflow, width adjustment, or wording change can prevent it. Check headings, cards, buttons, table cells, helper text, toast messages, and responsive breakpoints.
- Use word-break: normal or auto-phrase where supported, overflow-wrap: anywhere only for long URLs/IDs, and controlled white-space rules for labels. Do not globally use word-break: break-all for Chinese UI.
- Keep punctuation with the phrase it completes; avoid punctuation stranded at the beginning of the next line. Check parentheses, quotation marks, percentage signs, units, dates, and currency symbols as unbroken groups where possible.
- Use nonbreaking spans for short semantic units such as number + unit, date + weekday, keyboard shortcut, and product name when wrapping would harm comprehension.
- Do not solve orphan characters by shrinking text below the accessible/readable size. Adjust measure, copy, tracking, line-height, or layout first.
- Apply [copy-punctuation-contract.md](copy-punctuation-contract.md). Every visible Chinese string, including headings, navigation, tabs, buttons, badges, table headers, labels, helper text, validation, notifications, and empty states, ends with appropriate Chinese punctuation. Only a standalone brand/product name, pure numeric/value text, or an icon-only control may omit it.
- Maintain consistent punctuation style within a surface. Do not mix Chinese and ASCII punctuation without a deliberate technical reason.
- Check text at 320px mobile width, 200% zoom, large system fonts, and representative localization lengths. Never ship a line that contains a visually accidental single-character orphan.

## Motion Pairing

Pair rich interaction with the animation rules in [animation.md](animation.md). Every transition needs a state purpose, cancellation behavior, reduced-motion fallback, and no layout shift. 3D motion must not become continuous idle movement that drains battery or distracts from work.

## References

- [Three.js examples](https://threejs.org/examples/) — inspectable scene and interaction patterns.
- [React Three Fiber docs](https://r3f.docs.pmnd.rs) — React integration and performance guidance.
- [Babylon.js Playground](https://playground.babylonjs.com/) — browser-based 3D experiments.
- [MDN CSS text-wrap](https://developer.mozilla.org/docs/Web/CSS/text-wrap) — balanced and pretty text wrapping.
- [W3C CJK line breaking](https://www.w3.org/TR/clreq/) — Chinese typography and line-breaking requirements.
- [Material 3 shape](https://m3.material.io/styles/shape/overview) — shape hierarchy and component geometry.

Use these as behavior and implementation references. Rebuild the needed interaction in the product's own visual language and verify source licenses before copying code or assets.

## Acceptance

Inspect source and static layout rules for mouse, keyboard, touch, reduced motion, slow network, and a 320px fallback. Confirm any 3D scene has a clickable target, linked state update, 2D fallback, and context-loss path in code. Browser execution and manual interaction testing are not required unless separately requested.
