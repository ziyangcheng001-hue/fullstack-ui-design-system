# Style Diversity And Anti-Repetition

This reference prevents every generated frontend from collapsing into one familiar template. It applies whenever the user has not explicitly chosen a visual direction.

## No Default Template

Do not automatically use the same combination of dark background, neon accent, oversized left-aligned headline, right-side code panel, thin uppercase labels, floating model badges, and a pricing CTA. That is one possible direction, not a universal product pattern. Do not treat a previous generated page, starter screenshot, or the most convenient component library as the visual brief.

## Required Style Search

Before committing to a visual system, inspect at least three materially different families. At least two must come from different canonical sources or maintained projects. Compare:

| Family | Useful when | Questions to answer |
|---|---|---|
| Light editorial/content | Reading, documentation, publishing, education, brand storytelling | How are hierarchy, measure, media, and long-form states handled? |
| Dense utility/operations | Repeated work, tables, monitoring, admin, developer tools | How are filters, keyboard actions, density, and scanning handled? |
| Warm tactile/product | Consumer tools, commerce, onboarding, lifestyle workflows | How do shape, depth, illustration, and feedback support confidence? |
| Monochrome/minimal | Professional tools, finance, architecture, technical products | How is hierarchy created without decorative noise? |
| Playful/expressive | Community, creative tools, entertainment, youth audiences | How are motion, color, and personality kept usable? |
| Spatial/3D | Configuration, inspection, maps, simulation, visualization | What real task requires depth, and what is the 2D fallback? |
| Data/diagrammatic | Analytics, planning, systems, scientific or technical work | How are relationships, change, and uncertainty made inspectable? |

These are directions, not mandatory themes. The product domain, audience, brand, and content determine the final choice.

## Evidence And Selection

For every researched family, record:

- the actual URL or repository inspected;
- the specific page, component, interaction, typography, shape, or motion pattern observed;
- what fits the product;
- what must be rejected because of accessibility, license, performance, or mismatch;
- the selected family and at least two reasons it is better than the alternatives.

If the sources all point to the same visual family, search again using a different domain and query vocabulary. Galleries may inspire search terms, but the implementation source must be traced to a canonical repository or documented system.

## Variation Requirements

Across separate generated projects, vary composition according to the product instead of preserving a fixed hero recipe. Consider:

- navigation placement and behavior;
- content-first versus tool-first hierarchy;
- asymmetric, split, stacked, grid, canvas, timeline, or map compositions;
- light/dark/neutral surface treatment;
- typography-led, media-led, data-led, or interaction-led first viewport;
- contained panels versus full-width sections;
- inline detail, drawer, modal, split view, or route-based transitions.

Variation must remain coherent within one product. Do not randomize colors or layouts merely to look different.

## Anti-Repetition QA

Before delivery, compare the result against recent outputs or the user's supplied references. Reject and redesign when:

- the structure is the same left-copy/right-panel hero without a product reason;
- the palette, type scale, border treatment, and micro-label language are copied from a prior output;
- the page could be mistaken for a generic AI/API landing page despite a different domain;
- all visible motion is decorative and no interaction changes the composition;
- the chosen source was a template, but the product-specific behavior and content hierarchy were not reworked.

The handoff must name the chosen style family, the alternatives inspected, and the product-specific changes that make the result distinct.
